﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UserContactDemo.Models;
using PagedList;
using PagedList.Mvc;

namespace UserContactDemo.Controllers
{
    public class UserContactController : BaseController
    {
        private UserContactContext db = new UserContactContext();

        // GET: /UserContact/
        public ActionResult Index(string search,string searchBy, int? page)
        {
            Response.Write(System.Security.Principal.WindowsIdentity.GetCurrent().Name.ToString());
            if (searchBy == "FirstName")
            {
                return View(db.UserContacts.Where(con => con.C_First_Name.StartsWith(search) || search == null).ToList().ToPagedList(page ?? 1,3));
            }
            else
            {
                return View(db.UserContacts.Where(con => con.C_ast_Name.StartsWith(search) || search == null).ToList().ToPagedList(page ?? 1, 3));
            }
        }

        // GET: /UserContact/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserContact usercontact = db.UserContacts.Find(id);
            if (usercontact == null)
            {
                return HttpNotFound();
            }
            return View(usercontact);
        }

        // GET: /UserContact/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /UserContact/Create
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="ID,C_First_Name,C_ast_Name,Email,Phone_Number,Status")] UserContact usercontact)
        {
            if (ModelState.IsValid)
            {
                db.UserContacts.Add(usercontact);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(usercontact);
        }

        // GET: /UserContact/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserContact usercontact = db.UserContacts.Find(id);
            if (usercontact == null)
            {
                return HttpNotFound();
            }
            return View(usercontact);
        }

        // POST: /UserContact/Edit/5
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="ID,C_First_Name,C_ast_Name,Email,Phone_Number,Status")] UserContact usercontact)
        {
            if (ModelState.IsValid)
            {
                db.Entry(usercontact).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(usercontact);
        }

        // GET: /UserContact/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserContact usercontact = db.UserContacts.Find(id);
            if (usercontact == null)
            {
                return HttpNotFound();
            }
            return View(usercontact);
        }

        // POST: /UserContact/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            UserContact usercontact = db.UserContacts.Find(id);
            db.UserContacts.Remove(usercontact);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
