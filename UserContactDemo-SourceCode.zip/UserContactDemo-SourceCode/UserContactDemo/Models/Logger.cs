﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace UserContactDemo.Models
{
    public static class Logger
    {
        public static void Log(ExceptionContext ex)
        {
            string directory= AppDomain.CurrentDomain.BaseDirectory.ToString();
            string filePath = string.Format("{0}/{1}", directory, "Exception-"+DateTime.Now.ToFileTime()+".log");

            StreamWriter st = new StreamWriter(filePath,true);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Message");
            sb.AppendLine(ex.Exception.Message);
            sb.AppendLine("-----------------------------------------------------------");
            sb.AppendLine("Source");
            sb.AppendLine(ex.Exception.Source);
            sb.AppendLine("-----------------------------------------------------------");
            sb.AppendLine("StackTrace");
            sb.AppendLine(ex.Exception.StackTrace);
            

            st.Write(sb.ToString());
            st.Flush();
        }
    }
}