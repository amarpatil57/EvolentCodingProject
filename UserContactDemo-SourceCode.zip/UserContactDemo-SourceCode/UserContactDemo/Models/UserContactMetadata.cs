﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace UserContactDemo.Models
{
    public class UserContactMetadata
    {
        [Display(Name="First Name")]
        [Required(ErrorMessage = "Please Enter First Name")]
        public string C_First_Name { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Please Enter Last Name")]
        public string C_ast_Name { get; set; }
        [Display(Name = "Phone Number")]
        [Required(ErrorMessage = "Phone Number is Mandatory")]
        public int Phone_Number { get; set; }
        [RegularExpression("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$", ErrorMessage="Invalid Email Format")]
        [Required(ErrorMessage = "Email is Mandatory")]
        public string Email { get; set; }
        [Required(ErrorMessage="Please select status")]
        public Nullable<bool> Status { get; set; }

        
    }


    [MetadataType(typeof(UserContactMetadata))]
    public partial class UserContact
    {
        
    }
}